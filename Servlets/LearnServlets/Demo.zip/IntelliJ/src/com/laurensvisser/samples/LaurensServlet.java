package com.laurensvisser.samples;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.io.PrintWriter;

/**
 * Created by Laurens Visser on 16/05/2016.
 */
@WebServlet(name = "LaurensServlet", urlPatterns = {"/a/b/c","/servlets/laurens"})
public class LaurensServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>laurens</h1>");
        out.flush();

    }
}
