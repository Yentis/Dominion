package com.company;

/**
 * Created by Yentl-PC on 25/03/2016.
 */
public class NeemKaartGedrag {
    public void gedrag(int aantalkaarten, int kost, String locatie, Spel spel, String naam, String type){
        spel.verwijderVanVeld(naam, type);

    }
}
