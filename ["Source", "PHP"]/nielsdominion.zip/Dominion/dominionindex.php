
<?php
require_once "htmlkop.txt";
require_once "Dominionvisfuncties.php";


titeldominion();










require_once "htmlstaart.txt";
?>