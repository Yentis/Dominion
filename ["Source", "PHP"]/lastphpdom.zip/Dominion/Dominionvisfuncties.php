<?php
function titeldominion(){
    ?>

    <button type="button" class="button2">?</button>

    <h1>Dominion</h1>
    <form method="get" action="naamkeuzepagina.php">
    <button type="submit" class="button1"> Spelen</button>
    </form>

    <form>
    <button type="button" id = "afsluiten"> Afsluiten</button>
    </form>
    <audio controls autoplay loop>

        <source src="music/RuneScape%20Login%20Themes%202001-2014.mp3" type="audio/mpeg">

    </audio>


<?php
}

    ?>
<?php
function naamkeuzepagina(){
    ?>
    <form method="get" action="dominionindex.php">
    <button type="submit" class="vorigebutton"><strong><<</strong> Vorige</button>
    </form>
    <h3>Kies uw naam</h3>
    <div>
    <label>Speler 1:</label>
    <input type="text" id="speler1" name="speler1"/>
        </div>
    <div>
    <label>Speler 2:</label>
    <input type="text" id="speler2" name="speler2"/>
        </div>
    <button type="submit" class="startp2">Starten</button>

<?php
}

    ?>
<?php
function toonSpelRegels(){
    ?>
    <p>rugfihreigiuerhguirehgeighe</p>
    <?php
}

