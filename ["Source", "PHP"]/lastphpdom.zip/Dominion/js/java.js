/**
 * Created by niels on 14/04/2016.
 */
/**
 * Created by Renzie on 21/04/2016.
 */
$(document).ready(function () {

    console.log('derp');
    $(".button2").on("click",toonSpelRegels);
});


function toonSpelRegels(){

    var spelRegels = window.open("", "", "width=600,height=700");
    tmp = spelRegels.document;
    tmp.write('<html>');
    tmp.write('<head><link href="../css/style.css" rel="stylesheet" /></head>');
    tmp.write('<body>');
    tmp.write('<p>dit is een test als het werkt spring ik in de lucht</p>');
    tmp.write('</body>');
    tmp.write('</html>');


}