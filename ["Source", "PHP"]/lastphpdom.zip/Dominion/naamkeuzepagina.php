
<?php
require_once "htmlkop.txt";
require_once "Dominionvisfuncties.php";



 naamkeuzepagina();
require_once "htmlstaart.txt";
?>