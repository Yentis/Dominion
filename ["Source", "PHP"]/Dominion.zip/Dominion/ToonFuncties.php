<?php

function toonStartscherm() {
    ?>

    <audio controls autoplay loop>

        <source src="music/RuneScape%20Login%20Themes%202001-2014.mp3" type="audio/mpeg">

    </audio>

    <h1>Dominion</h1>

    <button type="button" class="button1"> Spelen

    </button>

    <button type="button"> Afsluiten

    </button>


    <script>
        function myFunction() {
            document.getElementById("muzieknoot").innerHTML = "Hello World";
        }
    </script>






<?php
}


    ?>