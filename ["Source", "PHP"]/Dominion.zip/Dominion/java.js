

var muziekuit = function(){
    $('#muzieknoot').addClass('off');

};





$(document).ready(function() {


    $('#muzieknoot').on('click',muziekuit);


});
