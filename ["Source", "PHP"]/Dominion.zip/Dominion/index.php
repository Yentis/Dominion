<?php
require_once "htmlkop.txt";
require_once "ToonFuncties.php";

toonStartscherm();
require_once "htmlstaart.txt";
?>


